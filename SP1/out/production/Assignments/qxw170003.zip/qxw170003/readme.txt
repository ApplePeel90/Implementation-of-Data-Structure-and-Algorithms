/* Hemali Amitkumar Patel hap170002
 *  Qi Wang qxw170003
 * */


For running code from terminal:
1. Go to the directory containing .java files
2. Compile file using javac #.java
3. Execute the file using java #.java

For running code from an IDE run the qxw1DoublyLinkedList.java file.

User can input any of the following methods to execute respective methods:
1:  Move to next element and print it
2:  Remove element
3:  Enter a number(x) to insert x before the element that will be returned by a call to next()
4:  Move to previous element and print it